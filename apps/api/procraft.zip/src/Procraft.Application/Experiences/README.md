Employment history editing operations.
