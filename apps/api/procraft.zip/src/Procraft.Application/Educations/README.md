Academic history editing operations.
