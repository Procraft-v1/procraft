namespace Procraft.Domain.Enums;

public enum SubscriptionStatus
{
    None = 0,
    Trial = 1,
    Active = 2,
    PastDue = 3,
    Canceled = 4,
}
