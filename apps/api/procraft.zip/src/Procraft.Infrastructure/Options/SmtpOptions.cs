namespace Procraft.Infrastructure.Options;

public sealed class SmtpOptions
{
    public string Host { get; init; } = string.Empty;

    public int Port { get; init; } = 587;

    public string Username { get; init; } = string.Empty;

    public string Password { get; init; } = string.Empty;

    public string FromAddress { get; init; } = "noreply@procraft.uz";

    public string FromName { get; init; } = "Procraft";

    public bool EnableSsl { get; init; } = true;
}
